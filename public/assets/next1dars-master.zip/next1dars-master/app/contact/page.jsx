function Contact() {
  return (
    <div>
      <h1 className="text-3xl font-bold">Contact</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo magni
        reprehenderit ea deleniti obcaecati in dolor quo quis, sapiente
        doloremque vel iusto qui iste dignissimos assumenda iure inventore
        distinctio. Exercitationem enim esse error officiis veniam. Quas
        distinctio placeat harum natus repellendus suscipit iste aliquid tenetur
        ex soluta dicta, quia vero?
      </p>
    </div>
  );
}

export default Contact;
