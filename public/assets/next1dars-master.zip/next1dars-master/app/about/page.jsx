export const metadata = {
  title: "About",
};

function About() {
  return (
    <div>
      <h1 className="text-3xl font-bold">About</h1>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro corrupti
        reprehenderit suscipit sunt nobis illo sequi magnam libero, nemo esse
        recusandae ducimus molestias tempore eum atque ab facere, autem
        assumenda. Nobis aperiam soluta nam. Quas tempore nostrum, cumque
        possimus perspiciatis numquam delectus voluptatibus reprehenderit
        facilis dolorem nobis vitae! Aliquid, magnam.
      </p>
    </div>
  );
}

export default About;
