import BasketList from "./BasketList";

function Basket() {
  return (
    <>
      <BasketList />
    </>
  );
}

export default Basket;
